# AI Assistants package (Pro / isolated)
