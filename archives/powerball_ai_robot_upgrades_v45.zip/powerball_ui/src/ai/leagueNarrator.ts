// ERROR: leagueNarrator.ts content missing.
