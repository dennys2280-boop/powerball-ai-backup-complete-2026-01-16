// src/App.jsx
import AppRoutes from "./routers.jsx";

export default function App() {
  return <AppRoutes />;
}
