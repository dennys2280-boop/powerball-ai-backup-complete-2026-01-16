// src/components/Section5PositionalFrequencyPanel.jsx
import React from "react";
import Card from "./Card";
import Section5PositionCard from "./Section5PositionCard";

/**
 * New panel for SECTION 5.
 * Renders a single title (panel-level) and a horizontal grid of 6 independent tables.
 */
export default function Section5PositionalFrequencyPanel({ section5 }) {
  const tables = section5?.tables || [];
  const sort = section5?.sort || {};
  const actions = section5?.actions || {};

  return (
    <Card
      title="Table 1 Extension"
      subtitle="Section 5 — Positional Frequency Analysis"
      className="mt-6"
    >
      <div className="text-sm text-slate-600">
        Progressive Decomposition By Position Using Filtered Results
      </div>

      <div className="mt-4 flex items-center justify-between gap-2 flex-wrap">
        <div className="text-xs text-slate-500">
          Excel Index Is Fixed (1–69). Sorting Controls Only Affect Ranked View.
        </div>

        <div className="flex items-center gap-2">
          <label className="text-xs text-slate-600">Apply Sort To All Tables</label>
          <select
            className="text-xs border rounded-lg px-2 py-1 bg-white"
            value={sort?.globalSort?.enabled ? sort.globalSort.dir : ""}
            onChange={(e) => {
              const dir = e.target.value;
              if (!dir) {
                actions?.clearGlobal?.();
                return;
              }
              actions?.applyGlobalToAllTables?.({ mode: "count", dir });
            }}
          >
            <option value="">Off</option>
            <option value="desc">Count Descending</option>
            <option value="asc">Count Ascending</option>
          </select>
        </div>
      </div>

      <div className="mt-5 flex gap-4 overflow-x-auto pb-2">
        {tables.map((t, idx) => {
          const resolved = sort?.resolvedForTable ? sort.resolvedForTable(idx) : { mode: "count", dir: "desc" };
          return (
            <Section5PositionCard
              key={t.position}
              table={t}
              sortConfig={resolved}
              onSortChange={(next) => actions?.setPerTable?.(idx, next)}
            />
          );
        })}
      </div>
    </Card>
  );
}
