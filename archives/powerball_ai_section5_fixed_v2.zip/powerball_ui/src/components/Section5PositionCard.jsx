// src/components/Section5PositionCard.jsx
import React, { useMemo } from "react";
import Card from "./Card";
import { getRankedByCount } from "../lib/section5PositionalFrequency";

function titleCasePosition(position) {
  if (position === 6) return "Position 6 (Powerball)";
  return `Position ${position}`;
}

function formatCombo(combo) {
  if (!Array.isArray(combo)) return "";
  return combo.join(" ");
}

export default function Section5PositionCard({ table, sortConfig, onSortChange }) {
  const position = table?.position ?? 1;
  const rows = table?.rows ?? [];

  const ranked = useMemo(() => {
    if (sortConfig?.mode !== "count") return [];
    return getRankedByCount(rows, sortConfig?.dir || "desc").slice(0, 10);
  }, [rows, sortConfig]);

  return (
    <Card
      title="Section 5 — Positional Frequency Analysis"
      subtitle={titleCasePosition(position)}
      className="min-w-[420px]"
    >
      <div className="flex items-center justify-between gap-2 flex-wrap">
        <div className="text-xs text-slate-500">
          Ranked View Uses Count (Excel Index Remains Fixed)
        </div>

        <div className="flex items-center gap-2">
          <label className="text-xs text-slate-600">Sort Count</label>
          <select
            className="text-xs border rounded-lg px-2 py-1 bg-white"
            value={sortConfig?.dir || "desc"}
            onChange={(e) => onSortChange?.({ mode: "count", dir: e.target.value })}
          >
            <option value="desc">Descending</option>
            <option value="asc">Ascending</option>
          </select>
        </div>
      </div>

      {ranked.length ? (
        <div className="mt-3 border border-slate-200 rounded-xl p-2">
          <div className="text-xs font-semibold text-slate-700">Top 10 By Count</div>
          <div className="mt-2 flex flex-wrap gap-1">
            {ranked.map((r) => (
              <span
                key={r.number}
                className="text-xs px-2 py-1 rounded-lg border border-slate-200 bg-slate-50"
                title={`Count: ${r.count}`}
              >
                {r.number} ({r.count})
              </span>
            ))}
          </div>
        </div>
      ) : null}

      <div className="mt-4 border border-slate-200 rounded-xl overflow-hidden">
        <div className="max-h-[420px] overflow-auto">
          <table className="w-full text-xs">
            <thead className="sticky top-0 bg-white border-b border-slate-200">
              <tr className="text-slate-600">
                <th className="p-2 text-left whitespace-nowrap">Excel Index</th>
                <th className="p-2 text-left whitespace-nowrap">Number</th>
                <th className="p-2 text-left whitespace-nowrap">Count</th>
                <th className="p-2 text-left">Filtered Combinations</th>
              </tr>
            </thead>

            <tbody>
              {rows.map((r) => (
                <tr key={r.excelIndex} className="border-b last:border-b-0">
                  <td className="p-2 whitespace-nowrap">{r.excelIndex}</td>
                  <td className="p-2 whitespace-nowrap">{r.number}</td>
                  <td className="p-2 whitespace-nowrap font-semibold">{r.count}</td>
                  <td className="p-2">
                    {r.combinations?.length ? (
                      <div className="flex flex-col gap-1">
                        {r.combinations.slice(0, 6).map((c, idx) => (
                          <div key={idx} className="text-[11px] text-slate-700">
                            {formatCombo(c)}
                          </div>
                        ))}
                        {r.combinations.length > 6 ? (
                          <div className="text-[11px] text-slate-500">
                            +{r.combinations.length - 6} More
                          </div>
                        ) : null}
                      </div>
                    ) : (
                      <span className="text-[11px] text-slate-400">—</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </Card>
  );
}
