from fastapi import FastAPI

app = FastAPI(
    title="Powerball + IA API",
    description="Backend para gestionar jugadas de Powerball y consultas con IA.",
    version="0.1.0",
)

@app.get("/")
def read_root():
    return {"message": "API de Powerball + IA funcionando 👌"}

@app.get("/status")
def get_status():
    return {"status": "ok", "detail": "Backend listo para recibir más funcionalidades."}

