// src/hooks/useSection5SortController.js
import { useCallback, useMemo, useState } from "react";

/**
 * Sort controller for SECTION 5.
 * Important: This does NOT reorder the base table rows (Excel Index is fixed).
 * It only controls:
 * - Ranked view direction (top/bottom lists)
 * - Highlight mode
 *
 * Precedence: customRules > tableSort > globalSort
 */

const DEFAULT_TABLE_SORT = { mode: "count", dir: "desc" }; // ranking default

export function useSection5SortController() {
  const [globalSort, setGlobalSort] = useState({ enabled: false, mode: "count", dir: "desc" });
  const [tableSort, setTableSort] = useState(() =>
    Array.from({ length: 6 }, () => ({ ...DEFAULT_TABLE_SORT }))
  );
  const [customRules, setCustomRules] = useState([]); // { tableIndex:0..5, mode, dir }

  const setPerTable = useCallback((tableIndex, next) => {
    setTableSort((prev) => {
      const copy = [...prev];
      copy[tableIndex] = { ...copy[tableIndex], ...next };
      return copy;
    });
  }, []);

  const applyGlobalToAllTables = useCallback((next) => {
    setGlobalSort((g) => ({ ...g, ...next, enabled: true }));
  }, []);

  const clearGlobal = useCallback(() => setGlobalSort((g) => ({ ...g, enabled: false })), []);

  const resolvedForTable = useCallback(
    (tableIndex) => {
      const rule = customRules.find((r) => r.tableIndex === tableIndex);
      if (rule) return { mode: rule.mode, dir: rule.dir, source: "custom" };
      if (globalSort.enabled) return { mode: globalSort.mode, dir: globalSort.dir, source: "global" };
      const t = tableSort[tableIndex] || DEFAULT_TABLE_SORT;
      return { mode: t.mode, dir: t.dir, source: "table" };
    },
    [customRules, globalSort, tableSort]
  );

  const actions = useMemo(
    () => ({
      setPerTable,
      applyGlobalToAllTables,
      clearGlobal,
      setCustomRules,
      setGlobalSort,
    }),
    [setPerTable, applyGlobalToAllTables, clearGlobal]
  );

  return {
    globalSort,
    tableSort,
    customRules,
    resolvedForTable,
    actions,
  };
}
