// src/components/Section5PositionCard.jsx
import React, { useMemo, useState } from "react";
import Card from "./Card";
import { getRankedByCount } from "../lib/section5PositionalFrequency";

function titleCasePosition(position) {
  if (position === 6) return "Position 6 (Powerball)";
  return `Position ${position}`;
}

function formatCombo(combo) {
  if (!Array.isArray(combo)) return "";
  return combo.join(" ");
}

export default function Section5PositionCard({ table, sortConfig, onSortChange, onApplyThisToAll, totalCount = 0, inputRows = 0 }) {
  const position = table?.position ?? 1;
  const rows = table?.rows ?? [];

  const ranked = useMemo(() => {
    if (sortConfig?.mode !== "count") return [];
    return getRankedByCount(rows, sortConfig?.dir || "desc").slice(0, 10);
  }, [rows, sortConfig, rankLimit]);

  const highlightSet = useMemo(() => new Set(ranked.map((x) => x.number)), [ranked]);

  return (
    <Card
      title={titleCasePosition(position)}
      subtitle="Positional Frequency Table"
      className="min-w-[420px]"
    >
      <div className="flex items-center justify-between gap-2 flex-wrap">
  <div className="text-xs text-slate-500">
    Excel Index Is Fixed (1–69). Sorting Controls Only Affect Ranked View.
  </div>

  <div className="flex items-center gap-2 flex-wrap">
    <label className="text-xs text-slate-600">Sort Count</label>
    <select
      className="text-xs border rounded-lg px-2 py-1 bg-white"
      value={sortConfig?.dir || "desc"}
      onChange={(e) => onSortChange?.({ mode: "count", dir: e.target.value })}
    >
      <option value="desc">Descending</option>
      <option value="asc">Ascending</option>
    </select>

    <label className="text-xs text-slate-600 ml-1">Rank Limit</label>
    <select
      className="text-xs border rounded-lg px-2 py-1 bg-white"
      value={rankLimit}
      onChange={(e) => setRankLimit(Number(e.target.value))}
    >
      <option value={5}>Top 5</option>
      <option value={10}>Top 10</option>
      <option value={20}>Top 20</option>
      <option value={50}>Top 50</option>
    </select>

    <button
      type="button"
      className="text-xs px-2 py-1 rounded-lg border border-slate-200 bg-slate-50 hover:bg-slate-100"
      onClick={() => onApplyThisToAll?.({ mode: "count", dir: sortConfig?.dir || "desc" })}
      title="Apply This Sort To All Tables"
    >
      Apply To All
    </button>
  </div>
</div>

<div className="mt-2 text-[11px] text-slate-500">
  Total Count: <span className="font-semibold text-slate-700">{totalCount}</span>{" "}
  • Input Rows: <span className="font-semibold text-slate-700">{inputRows}</span>{" "}
  {inputRows ? (
    totalCount === inputRows ? (
      <span className="ml-1 text-emerald-600 font-semibold">✓ Valid</span>
    ) : (
      <span className="ml-1 text-rose-600 font-semibold">⚠ Mismatch</span>
    )
  ) : null}
</div>

{ranked{ranked.length ? (
        <div className="mt-3 border border-slate-200 rounded-xl p-2">
          <div className="text-xs font-semibold text-slate-700">Top 10 By Count</div>
          <div className="mt-2 flex flex-wrap gap-1">
            {ranked.map((r) => (
              <span
                key={r.number}
                className="text-xs px-2 py-1 rounded-lg border border-slate-200 bg-slate-50"
                title={`Count: ${r.count}`}
              >
                {r.number} ({r.count})
              </span>
            ))}
          </div>
        </div>
      ) : null}

      <div className="mt-4 border border-slate-200 rounded-xl overflow-hidden">
        <div className="max-h-[420px] overflow-auto">
          <table className="w-full text-xs">
            <thead className="sticky top-0 bg-white border-b border-slate-200">
              <tr className="text-slate-600">
                <th className="p-2 text-left whitespace-nowrap">Excel Index</th>
                <th className="p-2 text-left whitespace-nowrap">Number</th>
                <th className="p-2 text-left whitespace-nowrap">Count</th>
                <th className="p-2 text-left">Filtered Combinations</th>
              </tr>
            </thead>

            <tbody>
              {rows.map((r) => (
                <tr key={r.excelIndex} className={`border-b last:border-b-0 ${highlightSet.has(r.number) && r.count > 0 ? "bg-amber-50" : ""}`}>
                  <td className="p-2 whitespace-nowrap">{r.excelIndex}</td>
                  <td className="p-2 whitespace-nowrap">{r.number}</td>
                  <td className="p-2 whitespace-nowrap font-semibold">{r.count}</td>
                  <td className="p-2">
                    {r.combinations?.length ? (
                      <div className="flex flex-col gap-1">
                        {r.combinations.slice(0, 6).map((c, idx) => (
                          <div key={idx} className="text-[11px] text-slate-700">
                            {formatCombo(c)}
                          </div>
                        ))}
                        {r.combinations.length > 6 ? (
                          <div className="text-[11px] text-slate-500">
                            +{r.combinations.length - 6} More
                          </div>
                        ) : null}
                      </div>
                    ) : (
                      <span className="text-[11px] text-slate-400">—</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </Card>
  );
}
