# Powerball Analytics — MASTER CONTRACT (Pointer)

The canonical signed contract lives at:

- powerball_api/docs/MASTER_CONTRACT.md

Open that file for Final v1.0.
